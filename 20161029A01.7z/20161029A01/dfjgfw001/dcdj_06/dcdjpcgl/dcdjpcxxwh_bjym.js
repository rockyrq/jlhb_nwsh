﻿$(function (){
	$("#dptabcontrol1").ligerTab({
		onBeforeSelectTabItem:function (tabid) {}, onAfterSelectTabItem: function (tabid){} 
	});
});


var pagecfg = {
	ctrlOpts : {
		uiflexgrid1:{
			dpType:'grid',
			enableflag:'isenabled',
			columns:[
				{ display:'操作',width:45,buttons:['bsc'] },
				{ display:'点检项目名称',id:'djxmmc',editor:{ type:'string' },name:'ITEMNAME',validator:{rules:{maxlength:50,required:true},messages:{required:'请输入点检项目名称'}},type:'string',width:250 },
				{ display:'工时',id:'gs',editor:{ type:'float' },name:'ITEMLABOR',defaultValue:0,formatter:'currency',validator:{rules:{range:[0,999999.99],required:true},messages:{required:'请输入工时'}},type:'float',width:80 },
				{ display:'工时费/小时',id:'gsf',editor:{ type:'float' },name:'ITEMLABORFEE',defaultValue:0,formatter:'currency',validator:{rules:{range:[0,999999.99],required:true},messages:{required:'请输入工时费/小时'}},type:'float',width:100 },
				{ display:'备注',id:'bz',editor:{ type:'string' },name:'REMARK',validator:{rules:{maxlength:400}},type:'string',width:200 },
				{ display:'项目及费用ID',id:'xmjfyid',isHide:true,isKey:true,name:'PRJITEMID',type:'int',width:100 }
			],
			usePager:false,
			rownumbers:true,
			height:'100%',
			minHeight:200,
			heightDiff:0,
			headerRowHeight:32,
			width:'auto',
			delayLoad:true,
			columnWidth:180,
			enabledSort:false,
			allowHideColumn:true,
			enabledEdit:true,
			clickToEdit:true,
			saveBindBtn:'bbc',
			toolbar: { items: [
				{text:'新增', icon:'', id:'bxz', click:clickGridButton}
			]},
			pageSize:20,
			pageSizeOptions:[5,10, 20, 30, 40, 50, 100]
		},
		bxz:{
			type:5,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			buttonType:0,
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		bsc:{
			type:6,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		uiflexgrid2:{
			dpType:'grid',
			enableflag:'isenabled',
			columns:[
				{ display:'操作',width:45,buttons:['bscdcl'] },
				{ display:'达成率起',id:'dclq',isHide:true,name:'dclq',isPost:false,width:120 },
				{ display:'达成率',id:'dclz',editor:{ type:'float' },name:'COMPLETIONRATEE',defaultValue:0,formatter:'currency',validator:{rules:{range:[0,1],required:true},messages:{required:'请输入达成率'}},type:'float',width:100 },
				{ display:'点检完成比例范围描述',id:'dclfwms',editor:{ type:'string' },name:'COMPLETIONRATEDESC',validator:{rules:{maxlength:100}},type:'string',width:150 },
				{ display:'支付比例',id:'zfbl',editor:{ type:'float' },name:'PAYRATE',defaultValue:0,formatter:'currency',validator:{rules:{range:[0,1],required:true},messages:{required:'请输入支付比例'}},type:'float',width:120 },
				{ display:'奖金',id:'jj',editor:{ type:'float' },name:'BONUS',defaultValue:0,formatter:'currency',validator:{rules:{range:[0,999999999999.99],required:true},messages:{required:'请输入奖金'}},type:'float',width:150 },
				{ display:'备注',id:'bz',editor:{ type:'string' },name:'REMARK',validator:{rules:{maxlength:400}},type:'string',width:200 },
				{ display:'点检达成率ID',id:'djdclid',isHide:true,isKey:true,name:'COMPLETPAYRATEID',type:'int',width:100 }
			],
			usePager:false,
			rownumbers:true,
			height:'100%',
			minHeight:200,
			heightDiff:0,
			headerRowHeight:32,
			width:'auto',
			delayLoad:true,
			columnWidth:180,
			enabledSort:false,
			allowHideColumn:true,
			enabledEdit:true,
			clickToEdit:true,
			saveBindBtn:'bbc',
			toolbar: { items: [
				{text:'新增', icon:'', id:'bxzdcl', click:clickGridButton}
			]},
			pageSize:20,
			pageSizeOptions:[5,10, 20, 30, 40, 50, 100]
		},
		bscdcl:{
			type:6,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid2',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		bxzdcl:{
			type:5,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid2',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			buttonType:0,
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		lbl_fzt:{
			showTip:true,
			dpType:'label'
		},
		fzt:{
			dpType:'combobox',
			disabled:true,
			isModify:false,
			pickListCode:'d688805c7b76e127',
			valueField:'VALCODE',
			textField:'VALNAME',
			haveEmptyRow:false,
			isMultiSelect:false,
			nullFirst:true,
			cmbInitType:0,
			casadeCtrl:[],
			emptyCtrl:[],
			dpDtype:'string'
		},
		fdjpcid:{
			dpType:'textbox',
			isKey:true,
			casadeCtrl:['uiflexgrid1','uiflexgrid2'],
			visible:false,
			dpDtype:'int'
		},
		fbbh:{
			dpType:'textbox',
			casadeCtrl:[],
			visible:false,
			dpDtype:'int'
		},
		lbl_flcf:{
			showTip:true,
			dpType:'label'
		},
		flcf:{
			dpType:'textbox',
			initValue:'0',
			casadeCtrl:[],
			validator:{rules:{number:true,range:[0,9999],required:true},messages:{required:'请输入旅程费：'}},
			statusAttribute:'enabled',
			statusRule:'F状态==\'A10\'',
			dpDtype:'float'
		},
		fdjxhggid:{
			dpType:'textbox',
			casadeCtrl:[],
			visible:false,
			disabled:true,
			isModify:false,
			dpDtype:'int'
		},
		fzyylsid:{
			dpType:'textbox',
			casadeCtrl:[],
			visible:false,
			disabled:true,
			dpDtype:'int'
		},
		lbl_fzyyls:{
			showTip:true,
			dpType:'label'
		},
		fzyyls:{
			dpType:'filepop',
			validator:{rules:{rangelength:[0,200]}},
			showType:1,
			fileId:{type:0,id:'fzyylsid'},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			manualInput:false,
			isMultiSelect:false,
			inArgument:{
			},
			outArgument:{
				cc:{
					'fzyylsid':'fwjid',
					'fzyyls':'fwjmc'
				},
				gc:{
					cc:{
					},
					retGridId:''
				}
			},
			emptyCtrl:[],
			openOpt:{
				h:330,
				w:540,
				title:'附件上传页面',
				modal:true,
				pageCode:'55eea2ff9bfee94b',
				childOpt:{
					initLoad:true,
					retGrid:'',
					retType:0,
					multInput:false
				}
			},
			dpDtype:'string'
		},
		lbl_fdjxhgg:{
			showTip:true,
			dpType:'label'
		},
		fdjxhgg:{
			dpType:'textboxpop',
			validator:{rules:{rangelength:[0,30],required:true},messages:{required:'请输入点检型号规格：'}},
			showType:1,
			isModify:false,
			statusAttribute:'enabled',
			statusRule:'F状态==\'A10\'',
			manualInput:false,
			isMultiSelect:false,
			emptyCtrl:['fdjxhggid'],
			inArgument:{
			},
			outArgument:{
				cc:{
				},
				gc:{
					cc:{
						'fdjxhgg':'SRVMODELCODE',
						'fdjxhggid':'SRVMODELID'
					},
					retGridId:'gcpxhlb'
				}
			},
			openOpt:{
				h:400,
				w:540,
				btnType:4,
				title:'选择型号规格单选',
				modal:true,
				pageCode:'f8beb0a62c03c220',
				childOpt:{
					initLoad:false,
					retGrid:'gcpxhlb',
					retType:0,
					multInput:false
				}
			},
			dpDtype:'string'
		},
		bbc:{
			type:1,
			showType:2,
			dpType:'button',
			okAndQuit:true,
			statusAttribute:'visible',
			statusRule:'F状态==\'A10\'|| F状态==\'A20\'',
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		bfh:{
			type:91,
			showType:2,
			dpType:'button',
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		lbl_fdjjhfwz:{
			showTip:true,
			dpType:'label'
		},
		fdjjhfwz:{
			dpType:'textbox',
			casadeCtrl:[],
			validator:{rules:{rangelength:[0,30],required:true},messages:{required:'请输入点检机号范围止：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\' || ctrls.fzt.getVal()==\'A20\'',
			dpDtype:'string'
		},
		lbl_fdjjhfwq:{
			showTip:true,
			dpType:'label'
		},
		fdjjhfwq:{
			dpType:'textbox',
			casadeCtrl:[],
			validator:{rules:{rangelength:[0,30],required:true},messages:{required:'请输入点检机号范围起：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\' || ctrls.fzt.getVal()==\'A20\'',
			dpDtype:'string'
		},
		lbl_fdjjhscrqz:{
			showTip:true,
			dpType:'label'
		},
		fdjjhscrqz:{
			dpType:'date',
			showType:0,
			refMinDate:'fdjjhscrqq',
			maxDate:'%y-%M-{%d+0}',
			validator:{rules:{required:true},messages:{required:'请输入生产日期止：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\' || ctrls.fzt.getVal()==\'A20\'',
			dpDtype:'date'
		},
		lbl_fdjjhscrqq:{
			showTip:true,
			dpType:'label'
		},
		fdjjhscrqq:{
			dpType:'date',
			showType:0,
			refMaxDate:'fdjjhscrqz',
			maxDate:'%y-%M-{%d+0}',
			validator:{rules:{required:true},messages:{required:'请输入生产日期起：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\' || ctrls.fzt.getVal()==\'A20\'',
			dpDtype:'date'
		},
		lbl_fdjssrqz:{
			showTip:true,
			dpType:'label'
		},
		fdjssrqz:{
			dpType:'date',
			showType:0,
			refMinDate:'fdjssrqq',
			validator:{rules:{required:true},messages:{required:'请输入点检实施日期止：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			dpDtype:'date'
		},
		lbl_fdjssrqq:{
			showTip:true,
			dpType:'label'
		},
		fdjssrqq:{
			dpType:'date',
			showType:0,
			refMaxDate:'fdjssrqz',
			validator:{rules:{required:true},messages:{required:'请输入点检实施日期起：'}},
			statusAttribute:'enabled',
			statusRule:'ctrls.fzt.getVal()==\'A10\'',
			dpDtype:'date'
		},
		lbl_fxmmc:{
			showTip:true,
			dpType:'label'
		},
		fxmmc:{
			dpType:'textbox',
			casadeCtrl:[],
			validator:{rules:{rangelength:[0,50],required:true},messages:{required:'请输入项目名称：'}},
			statusAttribute:'enabled',
			statusRule:'F状态==\'A10\'',
			dpDtype:'string'
		},
		lbl_fdjpc:{
			showTip:true,
			dpType:'label'
		},
		fdjpc:{
			dpType:'textbox',
			casadeCtrl:[],
			disabled:true,
			isModify:false,
			dpDtype:'string'
		},
		lbl_fbz:{
			showTip:true,
			dpType:'label'
		},
		fbz:{
			dpType:'richtextbox',
			richEditor:'RichText',
			statusAttribute:'enabled',
			statusRule:'F状态==\'A10\'',
			dpDtype:'string'
		},
		ctrlOptend : {}
	},
	formOpts : {
			uipanel1: {
				saveBindBtn:'bbc'
			}
	},
	pageOpts : {
		defaultFocus:'fxmmc',
		acceptCtrl:'bbc',
		cancelCtrl:'bfh',
		pageCode:'c0b707654ae40ef5'
	}
};

_beforeStatusInit = function(_cfg){
	$.dpui.addCtrlEvent(_cfg, 'fzt', 'afterChange', function(ctrl){
		var el1 = ($.dpui.getCtrlVal('fzt')=='A10');
		if (el1) {
			ctrl.getPage().getCtrl('fdjssrqq').setCtrlStatus(false);
			ctrl.getPage().getCtrl('fdjssrqz').setCtrlStatus(false);
			ctrl.getPage().getCtrl('uiflexgrid2').setCtrlStatus(false);
			ctrl.getPage().getCtrl('bxz').show();
			ctrl.getPage().getCtrl('bxz').setCtrlStatus();

			ctrl.getPage().getCtrl('bsc').show();
			ctrl.getPage().getCtrl('bsc').setCtrlStatus();

			ctrl.getPage().getCtrl('uiflexgrid1').setCtrlStatus(false);
			ctrl.getPage().getCtrl('fzyyls').setCtrlStatus(false);
			ctrl.getPage().getCtrl('bxzdcl').show();
			ctrl.getPage().getCtrl('bxzdcl').setCtrlStatus();

			ctrl.getPage().getCtrl('bscdcl').show();
			ctrl.getPage().getCtrl('bscdcl').setCtrlStatus();

		} else {
			ctrl.getPage().getCtrl('fdjssrqq').setDisabled(true);
			ctrl.getPage().getCtrl('fdjssrqz').setDisabled(true);
			ctrl.getPage().getCtrl('uiflexgrid2').setDisabled(true);
			ctrl.getPage().getCtrl('bxz').hide();
			ctrl.getPage().getCtrl('bsc').hide();
			ctrl.getPage().getCtrl('uiflexgrid1').setDisabled(true);
			ctrl.getPage().getCtrl('fzyyls').setDisabled(true);
			ctrl.getPage().getCtrl('bxzdcl').hide();
			ctrl.getPage().getCtrl('bscdcl').hide();
		}
		var el2 = ($.dpui.getCtrlVal('fzt')=='A10' || $.dpui.getCtrlVal('fzt')=='A20');
		if (el2) {
			ctrl.getPage().getCtrl('fdjjhscrqq').setCtrlStatus(false);
			ctrl.getPage().getCtrl('fdjjhscrqz').setCtrlStatus(false);
			ctrl.getPage().getCtrl('fdjjhfwq').setCtrlStatus(false);
			ctrl.getPage().getCtrl('fdjjhfwz').setCtrlStatus(false);
		} else {
			ctrl.getPage().getCtrl('fdjjhscrqq').setDisabled(true);
			ctrl.getPage().getCtrl('fdjjhscrqz').setDisabled(true);
			ctrl.getPage().getCtrl('fdjjhfwq').setDisabled(true);
			ctrl.getPage().getCtrl('fdjjhfwz').setDisabled(true);
		}
		return false;
	});

	return false;
};

var __dpCahce,_beforeDPPageInit,_afterDPPageInit;
var _beforeStatusInit,_beforeCalculationInit,_beforePreRuleInit,_beforeEmptyInit;
var _afterSelectChangeInit,_beforeGridBeforeEditInit,_afterGridAddtionRelaInit,_afterTreeClickInit,_afterGridChangeInit;

$(function(){
	if($.type(_beforeDPPageInit) == 'function') { if(_beforeDPPageInit(pagecfg)) return; }

	if($.type(_beforeStatusInit) == 'function') { if(_beforeStatusInit(pagecfg)) return; }
	if($.type(_beforeCalculationInit) == 'function') { if(_beforeCalculationInit(pagecfg)) return; }
	if($.type(_beforePreRuleInit) == 'function') { if(_beforePreRuleInit(pagecfg)) return; }
	if($.type(_beforeGridBeforeEditInit) == 'function') { if(_beforeGridBeforeEditInit(pagecfg)) return; }
	if($.type(_beforeEmptyInit) == 'function') { if(_beforeEmptyInit(pagecfg)) return; }
	if($.type(_afterSelectChangeInit) == 'function') { if(_afterSelectChangeInit(pagecfg)) return; }
	if($.type(_afterTreeClickInit) == 'function') { if(_afterTreeClickInit(pagecfg)) return; }
	if($.type(_afterGridAddtionRelaInit) == 'function') { if(_afterGridAddtionRelaInit(pagecfg)) return; }
	if($.type(_afterGridChangeInit) == 'function') { if(_afterGridChangeInit(pagecfg)) return; }

	__dpCahce = $.dpui.initPage(pagecfg, contextDS, pickListDS, pageInitDS);

});
