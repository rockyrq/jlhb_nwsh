﻿
var pagecfg = {
	ctrlOpts : {
		uiflexgrid1:{
			dpType:'grid',
			enableflag:'isenabled',
			columns:[
				{ display:'操作',width:315,buttons:['bxg','bsc','bfb','bsyfws','bjz','bja'] },
				{ display:'作业要领书',id:'zyyls',name:'PRJOPERATEMAN',validator:{rules:{maxlength:200}},isHyperLink:true,defaultText:'',buttons:['uiflexgrid1zyyls'],type:'string',width:120 },
				{ display:'作业要领书ID',id:'zyylsid',isHide:true,name:'PRJOPERATEMANID',type:'int',width:100 },
				{ display:'点检批次',id:'djpc',name:'PROJECTCODE',validator:{rules:{maxlength:30}},isHyperLink:true,defaultText:'请选择',buttons:['uiflexgrid1djpc'],type:'string',width:160 },
				{ display:'项目名称',id:'xmmc',name:'PRJNAME',type:'string',width:200 },
				{ display:'点检型号规格',id:'djxhgg',name:'PRJMODELCODE',type:'string',width:150 },
				{ display:'点检型号规格ID',id:'djxhggid',isHide:true,name:'PRJMODELID',type:'int',width:100 },
				{ display:'机号范围起',id:'jhfwq',name:'PRJBCSNO',type:'string',width:100 },
				{ display:'机号范围止',id:'jhfwz',name:'PRJECSNO',type:'string',width:100 },
				{ display:'生产日期起',id:'scrqq',name:'BPRODUCTDATE',format:'yyyy-MM-dd',type:'date',width:100 },
				{ display:'生产日期止',id:'scrqz',name:'EPRODUCTDATE',format:'yyyy-MM-dd',type:'date',width:100 },
				{ display:'点检日期起',id:'djrqq',name:'PRJBEGINDATE',format:'yyyy-MM-dd',type:'date',width:100 },
				{ display:'点检日期止',id:'djrqz',name:'PRJENDDATE',format:'yyyy-MM-dd',type:'date',width:100 },
				{ display:'状态',id:'zt',name:'PRJSTATUS',pickListCode:'rd688805c7b76e127',valueField:'VALCODE',textField:'VALNAME',type:'string',width:100 },
				{ display:'检点批次ID',id:'jdpcid',isHide:true,isKey:true,name:'PROJECTID',type:'int',width:100 },
				{ display:'版本号',id:'bbh',isHide:true,name:'VERSION',type:'int',width:100 }
			],
			usePager:true,
			rownumbers:true,
			height:'100%',
			minHeight:200,
			heightDiff:0,
			headerRowHeight:32,
			width:'auto',
			delayLoad:true,
			columnWidth:180,
			enabledSort:false,
			allowHideColumn:true,
			enabledEdit:false,
			queryBindBtn:'bcx',
			toolbar: { items: [
				{text:'新增', icon:'', id:'bxz', click:clickGridButton}
			]},
			pageSize:20,
			pageSizeOptions:[5,10, 20, 30, 40, 50, 100]
		},
		bja:{
			type:3,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A40\'',
			bindForms:['uiflexgrid1_form'],
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preConfirm:'是否确认结案？',
			afterMessage:'结案完成！',
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		bjz:{
			type:3,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A20\'',
			bindForms:['uiflexgrid1_form'],
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preConfirm:'是否确认截至?',
			afterMessage:'截至成功！',
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		bsyfws:{
			type:11,
			showType:1,
			dpType:'gridbutton',
			btnType:2,
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A10\' || rowdata.PRJSTATUS==\'A20\' ',
			buttonType:1,
			inArgument:{
				cg:{
					'fdjxmpcid':'PROJECTID',
					'qdjxmpcid':'PROJECTID'
				}
			},
			outArgument:{
			},
			powerCheck:true,
			isMultiSelect:false,
			openOpt:{
				h:600,
				w:900,
				title:'对策点检项目批次适用服务商维护',
				modal:true,
				pageCode:'a19e8ca8e628184a',
				childOpt:{
					initLoad:false,
					retGrid:'',
					retType:0,
					multInput:false
				}
			},
			preEvent:[],
			afterEvent:[]
		},
		bfb:{
			type:3,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A10\'',
			bindForms:['uiflexgrid1_form'],
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preConfirm:'是否确认发布？',
			afterMessage:'发布成功！',
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		bsc:{
			type:3,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A10\'',
			bindForms:['uiflexgrid1_form'],
			buttonType:1,
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preConfirm:'是否确认删除该记录？',
			afterMessage:'删除成功！',
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		bxg:{
			type:11,
			showType:1,
			dpType:'gridbutton',
			btnType:2,
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			statusAttribute:'visible',
			statusRule:'rowdata.PRJSTATUS==\'A10\'||rowdata.PRJSTATUS==\'A20\'',
			buttonType:1,
			inArgument:{
				cg:{
					'fdjpcid':'PROJECTID',
					'fbbh':'VERSION'
				}
			},
			outArgument:{
			},
			powerCheck:true,
			isMultiSelect:false,
			openOpt:{
				h:540,
				w:900,
				title:'对策点检批次信息维护',
				modal:true,
				pageCode:'c0b707654ae40ef5',
				childOpt:{
					initLoad:false,
					retGrid:'',
					retType:0,
					multInput:false
				}
			},
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		bxz:{
			type:11,
			showType:1,
			dpType:'gridbutton',
			btnType:1,
			bindGrid:'uiflexgrid1',
			gridValueRequired:1,
			buttonType:0,
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			isMultiSelect:false,
			openOpt:{
				h:500,
				w:900,
				title:'对策点检批次信息维护',
				modal:true,
				pageCode:'c0b707654ae40ef5',
				childOpt:{
					initLoad:false,
					retGrid:'',
					retType:0,
					multInput:false
				}
			},
			preEvent:[],
			afterEvent:['uiflexgrid1']
		},
		uiflexgrid1zyyls:{
			type:111,
			showType:2,
			dpType:'gridbutton',
			bindGrid:'uiflexgrid1',
			buttonType:1,
			isMultiSelect:false,
			fileId:{type:1,id:'PRJOPERATEMANID'},
			afterEvent:[]
		},
		uiflexgrid1djpc:{
			type:10,
			showType:1,
			dpType:'gridbutton',
			btnType:9,
			bindGrid:'uiflexgrid1',
			buttonType:1,
			isMultiSelect:false,
			inArgument:{
				cc:{
				},
				cg:{
					'fdjpcid':'PROJECTID'
				}
			},
			outArgument:{
			},
			openOpt:{
				h:540,
				w:900,
				btnType:9,
				title:'点检批次信息查看',
				modal:true,
				pageCode:'c0b707654ae40ef5',
				childOpt:{
					initLoad:false,
					retGrid:'',
					retType:0,
					multInput:false
				}
			},
			afterEvent:[]
		},
		lbl_qdjxhgg:{
			showTip:true,
			dpType:'label'
		},
		qdjxhgg:{
			dpType:'textboxpop',
			isQParm:true,
			likeMode:3,
			showType:1,
			manualInput:true,
			isMultiSelect:false,
			emptyCtrl:['qdjxhggid'],
			inArgument:{
			},
			outArgument:{
				cc:{
				},
				gc:{
					cc:{
						'qdjxhggid':'SRVMODELID',
						'qdjxhgg':'SRVMODELCODE'
					},
					retGridId:'uiflexgrid'
				}
			},
			openOpt:{
				h:450,
				w:780,
				btnType:4,
				title:'服务机型选择',
				modal:true,
				pageCode:'dc735b632905d91a',
				childOpt:{
					initLoad:false,
					retGrid:'uiflexgrid',
					retType:0,
					multInput:false
				}
			},
			dpDtype:'string'
		},
		qdjxhggid:{
			dpType:'textbox',
			isQParm:true,
			likeMode:2,
			casadeCtrl:[],
			visible:false,
			disabled:true,
			dpDtype:'int'
		},
		lbl_qzt:{
			showTip:true,
			dpType:'label'
		},
		qzt:{
			dpType:'combobox',
			isQParm:true,
			pickListCode:'d688805c7b76e127',
			valueField:'VALCODE',
			textField:'VALNAME',
			haveEmptyRow:true,
			isMultiSelect:false,
			nullFirst:true,
			cmbInitType:0,
			casadeCtrl:[],
			emptyCtrl:[],
			dpDtype:'string'
		},
		bzz:{
			type:20,
			showType:2,
			dpType:'button',
			inArgument:{
			},
			outArgument:{
			},
			powerCheck:true,
			resetType:0,
			preEvent:[],
			afterEvent:[]
		},
		bcx:{
			type:0,
			showType:2,
			dpType:'button',
			bindForms:['uipanel1'],
			inArgument:{
			},
			outArgument:{
			},
			requireCheck:true,
			powerCheck:true,
			preEvent:[],
			afterEvent:[]
		},
		lbl_qxmmc:{
			showTip:true,
			dpType:'label'
		},
		qxmmc:{
			dpType:'textbox',
			isQParm:true,
			likeMode:3,
			casadeCtrl:[],
			dpDtype:'string'
		},
		lbl_qdjpc:{
			showTip:true,
			dpType:'label'
		},
		qdjpc:{
			dpType:'textbox',
			isQParm:true,
			likeMode:3,
			casadeCtrl:[],
			dpDtype:'string'
		},
		ctrlOptend : {}
	},
	formOpts : {
			uipanel1: {
				queryBindBtn:'bcx'
			}
	},
	pageOpts : {
		defaultCtrl:'bcx',
		pageCode:'5e80030be767270e'
	}
};

var __dpCahce,_beforeDPPageInit,_afterDPPageInit;
var _beforeStatusInit,_beforeCalculationInit,_beforePreRuleInit,_beforeEmptyInit;
var _afterSelectChangeInit,_beforeGridBeforeEditInit,_afterGridAddtionRelaInit,_afterTreeClickInit,_afterGridChangeInit;

$(function(){
	if($.type(_beforeDPPageInit) == 'function') { if(_beforeDPPageInit(pagecfg)) return; }

	if($.type(_beforeStatusInit) == 'function') { if(_beforeStatusInit(pagecfg)) return; }
	if($.type(_beforeCalculationInit) == 'function') { if(_beforeCalculationInit(pagecfg)) return; }
	if($.type(_beforePreRuleInit) == 'function') { if(_beforePreRuleInit(pagecfg)) return; }
	if($.type(_beforeGridBeforeEditInit) == 'function') { if(_beforeGridBeforeEditInit(pagecfg)) return; }
	if($.type(_beforeEmptyInit) == 'function') { if(_beforeEmptyInit(pagecfg)) return; }
	if($.type(_afterSelectChangeInit) == 'function') { if(_afterSelectChangeInit(pagecfg)) return; }
	if($.type(_afterTreeClickInit) == 'function') { if(_afterTreeClickInit(pagecfg)) return; }
	if($.type(_afterGridAddtionRelaInit) == 'function') { if(_afterGridAddtionRelaInit(pagecfg)) return; }
	if($.type(_afterGridChangeInit) == 'function') { if(_afterGridChangeInit(pagecfg)) return; }

	__dpCahce = $.dpui.initPage(pagecfg, contextDS, pickListDS, pageInitDS);

});
